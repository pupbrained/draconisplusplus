#pragma once

void setup_quill(char const* log_file);